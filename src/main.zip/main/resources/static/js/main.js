async function subscribeToPush() {
    const register = await navigator.serviceWorker.register("/sw.js");

    const subscription = await register.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: "YOUR_PUBLIC_VAPID_KEY"
    });

    await fetch("/api/subscribe", {
        method: "POST",
        body: JSON.stringify(subscription),
        headers: { "Content-Type": "application/json" }
    });

    alert("Push subscription sent to server!");
}

// Gọi khi load trang hoặc khi người dùng bấm nút
window.addEventListener('load', () => {
    if ('serviceWorker' in navigator && 'PushManager' in window) {
        subscribeToPush().catch(console.error);
    } else {
        console.warn("Push notification is not supported.");
    }
});
